package com.cineforge.ai

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.ViewGroup
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val BG = Color(0xFF080A16)
private val CARD = Color(0xFF12162A)
private val TXT = Color(0xFFF5F7FF)
private val DIM = Color(0xFFA8AEC5)
private val BLUE = Color(0xFF55A7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        setContent { CineForgeApp() }
    }
}

data class JobResult(
    val id: String,
    val status: String,
    val progress: Float,
    val videoUrl: String?
)

@Composable
fun CineForgeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("cineforge", Context.MODE_PRIVATE) }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var screen by remember { mutableStateOf("home") }
    var script by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("10 minutes") }
    var jobId by remember { mutableStateOf<String?>(null) }
    var videoUrl by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = CARD, primary = BLUE)) {
        Surface(modifier = Modifier.fillMaxSize(), color = BG) {
            when (screen) {
                "create" -> Create(
                    back = { screen = "home" },
                    initialScript = script,
                    initialDuration = duration,
                    onGenerate = { newScript, newDuration ->
                        script = newScript
                        duration = newDuration
                        if (backendUrl.isBlank()) {
                            errorMessage = "First open Free Engine and enter your Colab backend URL."
                        } else if (newScript.isBlank()) {
                            errorMessage = "Please paste your screenplay first."
                        } else {
                            errorMessage = null
                            jobId = null
                            videoUrl = null
                            screen = "generating"
                            scope.launch {
                                try {
                                    jobId = withContext(Dispatchers.IO) { createJob(backendUrl, newScript, newDuration) }
                                } catch (e: Exception) {
                                    errorMessage = e.message ?: "Could not connect to the backend."
                                    screen = "create"
                                }
                            }
                        }
                    },
                    errorMessage = errorMessage,
                    clearError = { errorMessage = null }
                )

                "generating" -> Generating(
                    back = { screen = "home" },
                    backendUrl = backendUrl,
                    jobId = jobId,
                    onDone = { url ->
                        videoUrl = url
                        screen = "movie"
                    },
                    onError = { message ->
                        errorMessage = message
                        screen = "create"
                    }
                )

                "movie" -> Movie(
                    back = { screen = "home" },
                    videoUrl = videoUrl,
                    backendUrl = backendUrl,
                    onRegenerate = { editPrompt ->
                        if (backendUrl.isBlank() || script.isBlank()) {
                            errorMessage = "Backend or screenplay is missing."
                        } else {
                            screen = "generating"
                            scope.launch {
                                try {
                                    jobId = withContext(Dispatchers.IO) { createJob(backendUrl, "$script\n\nEDIT REQUEST: $editPrompt", duration) }
                                } catch (e: Exception) {
                                    errorMessage = e.message ?: "Could not start regeneration."
                                    screen = "movie"
                                }
                            }
                        }
                    }
                )

                "library" -> Library(home = { screen = "home" })
                "about" -> About(back = { screen = "home" })
                "settings" -> BackendSettings(
                    currentUrl = backendUrl,
                    onBack = { screen = "home" },
                    onSave = { value ->
                        backendUrl = value.trim().removeSuffix("/")
                        prefs.edit().putString("backend_url", backendUrl).apply()
                        screen = "home"
                    }
                )
                else -> Home(
                    create = { screen = "create" },
                    lib = { screen = "library" },
                    about = { screen = "about" },
                    settings = { screen = "settings" },
                    backendReady = backendUrl.isNotBlank()
                )
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null, back: (() -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) {
            Text(
                text = "‹",
                color = TXT,
                fontSize = 34.sp,
                modifier = Modifier.clickable { back() }.padding(end = 12.dp)
            )
        }
        Column {
            Text(text = title, color = TXT, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(text = it, color = DIM, fontSize = 13.sp) }
        }
    }
}

@Composable
fun BoxCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(listOf(CARD, Color(0xFF171B35))),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(18.dp),
        content = content
    )
}

@Composable
fun ButtonX(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(text = text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Home(
    create: () -> Unit,
    lib: () -> Unit,
    about: () -> Unit,
    settings: () -> Unit,
    backendReady: Boolean
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "CineForge AI", subtitle = "Your Idea. Your Story. Your Movie.")
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                BoxCard {
                    Text(text = "AI Movie Maker", color = TXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Paste a screenplay. CineForge sends it to your free open-source video engine and returns a real MP4 when generation finishes.",
                        color = DIM,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    ButtonX(text = "＋ Create New Movie", onClick = create)
                }
            }
            item { Tile("🎬", "My Movies", "View projects", lib) }
            item {
                Tile(
                    "✦",
                    "Free Engine",
                    if (backendReady) "Connected to your Colab engine" else "Connect free Colab engine",
                    settings
                )
            }
            item { Tile("ⓘ", "About CineForge AI", "Founder and project information", about) }
        }
        Bottom(lib = lib, profile = about)
    }
}

@Composable
fun Tile(icon: String, title: String, description: String, onClick: () -> Unit) {
    BoxCard {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { onClick() },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = icon, fontSize = 27.sp)
            Spacer(modifier = Modifier.width(15.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TXT, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(text = description, color = DIM, fontSize = 13.sp)
            }
            Text(text = "›", color = DIM, fontSize = 27.sp)
        }
    }
}

@Composable
fun Bottom(lib: () -> Unit, profile: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF0C0F20)).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Text(text = "⌂ Home", color = TXT, modifier = Modifier.padding(10.dp))
        Text(text = "▣ Library", color = DIM, modifier = Modifier.clickable { lib() }.padding(10.dp))
        Text(text = "● Profile", color = DIM, modifier = Modifier.clickable { profile() }.padding(10.dp))
    }
}

@Composable
fun Create(
    back: () -> Unit,
    initialScript: String,
    initialDuration: String,
    onGenerate: (String, String) -> Unit,
    errorMessage: String?,
    clearError: () -> Unit
) {
    var script by remember(initialScript) { mutableStateOf(initialScript) }
    var duration by remember(initialDuration) { mutableStateOf(initialDuration) }
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Create New Movie", subtitle = "Screenplay → real video generation", back = back)
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                BoxCard {
                    Text(text = "FULL SCREENPLAY", color = BLUE, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = script,
                        onValueChange = { script = it },
                        modifier = Modifier.fillMaxWidth().height(280.dp),
                        placeholder = { Text(text = "Paste your complete movie screenplay here…") }
                    )
                }
            }
            item {
                BoxCard {
                    Text(text = "MOVIE DURATION", color = TXT, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = duration,
                        onValueChange = { duration = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(text = "e.g. 10 minutes") }
                    )
                }
            }
            item {
                BoxCard {
                    Text(text = "FREE GENERATION", color = TXT, fontWeight = FontWeight.Bold)
                    Text(
                        text = "The first free engine version generates short AI scenes and joins them into an MP4. Free Colab GPU availability is not guaranteed, so very long movies may need multiple runs.",
                        color = DIM,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
            if (errorMessage != null) {
                item {
                    BoxCard {
                        Text(text = errorMessage, color = Color(0xFFFF8A8A))
                        TextButton(onClick = clearError) { Text(text = "Dismiss") }
                    }
                }
            }
        }
        Box(modifier = Modifier.padding(20.dp)) {
            ButtonX(text = "Generate Real Movie", onClick = { onGenerate(script, duration) })
        }
    }
}

@Composable
fun Generating(
    back: () -> Unit,
    backendUrl: String,
    jobId: String?,
    onDone: (String) -> Unit,
    onError: (String) -> Unit
) {
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("Sending screenplay to the free engine…") }

    LaunchedEffect(jobId, backendUrl) {
        if (jobId.isNullOrBlank()) return@LaunchedEffect
        try {
            while (true) {
                val result = withContext(Dispatchers.IO) { getJob(backendUrl, jobId) }
                progress = result.progress
                status = result.status
                if (result.status == "completed" && !result.videoUrl.isNullOrBlank()) {
                    onDone(result.videoUrl)
                    break
                }
                if (result.status == "failed") {
                    onError(result.videoUrl ?: "Generation failed on the backend.")
                    break
                }
                delay(2500)
            }
        } catch (e: Exception) {
            onError(e.message ?: "Lost connection to the free engine.")
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Generating Your Movie", subtitle = "Real backend generation — not a fake timer", back = back)
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            BoxCard {
                Text(text = "CineForge AI Free Engine", color = TXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text(
                    text = "${(progress * 100).toInt()}% • $status",
                    color = DIM,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            BoxCard {
                Text(text = "What is happening", color = TXT, fontWeight = FontWeight.Bold)
                listOf("Splitting screenplay into scenes", "Generating AI video clips", "Joining clips into one MP4", "Preparing the movie for preview and download").forEach {
                    Text(text = "•  $it", color = DIM, modifier = Modifier.padding(vertical = 5.dp))
                }
            }
        }
    }
}

@Composable
fun Movie(
    back: () -> Unit,
    videoUrl: String?,
    backendUrl: String,
    onRegenerate: (String) -> Unit
) {
    var showEdit by remember { mutableStateOf(false) }
    var editText by remember { mutableStateOf("Make the selected scenes more cinematic and dramatic.") }
    val videoViewRef = remember { VideoViewRef() }

    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Final Movie", subtitle = "Preview, regenerate and download", back = back)
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(230.dp).background(Color.Black, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!videoUrl.isNullOrBlank()) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                    setVideoURI(Uri.parse(videoUrl))
                                    setOnPreparedListener { mp -> mp.isLooping = false }
                                    videoViewRef.view = this
                                }
                            }
                        )
                    } else {
                        Text(text = "No video returned", color = TXT)
                    }
                }
            }
            item {
                BoxCard {
                    Text(text = "Generated Movie", color = TXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (videoUrl.isNullOrBlank()) "The engine did not return an MP4." else "Your real generated MP4 is ready.",
                        color = DIM
                    )
                }
            }
            item {
                ButtonX(text = "▶ Play Movie", onClick = {
                    videoViewRef.view?.start()
                })
            }
            item {
                ButtonX(text = "Edit / Regenerate Scene", onClick = { showEdit = true })
            }
            item {
                OutlinedButton(
                    onClick = {
                        if (!videoUrl.isNullOrBlank()) {
                            downloadVideo(backendUrl, videoUrl)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(text = "Download Movie")
                }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text(text = "Regenerate Movie") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showEdit = false
                    onRegenerate(editText)
                }) { Text(text = "Generate") }
            },
            dismissButton = {
                TextButton(onClick = { showEdit = false }) { Text(text = "Cancel") }
            }
        )
    }
}

@Composable
fun BackendSettings(currentUrl: String, onBack: () -> Unit, onSave: (String) -> Unit) {
    var value by remember(currentUrl) { mutableStateOf(currentUrl) }
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Free Engine", subtitle = "Google Colab backend URL", back = onBack)
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            BoxCard {
                Text(text = "BACKEND URL", color = BLUE, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(text = "https://xxxxx.trycloudflare.com") }
                )
                Text(
                    text = "Start the free Colab engine, copy its public URL, and paste it here. No paid API key is required.",
                    color = DIM,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            ButtonX(text = "Save Free Engine", onClick = { onSave(value) })
        }
    }
}

@Composable
fun Library(home: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "My Movies", subtitle = "Your projects")
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(listOf("Generated Movie", "My First Story", "CineForge Test")) {
                Tile("🎞", it, "Movie project", {})
            }
        }
        Bottom(lib = {}, profile = home)
    }
}

@Composable
fun About(back: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "About CineForge AI", subtitle = "The idea behind the app", back = back)
        LazyColumn(contentPadding = PaddingValues(20.dp)) {
            item {
                BoxCard {
                    Text(text = "Meet the Founder", color = TXT, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "This application was born from an idea to make AI-powered filmmaking simple and accessible to everyone.\n\nCineForge AI is being developed as an open, accessible movie-making experience where people can turn a screenplay into scenes, voices, music, sound and video.\n\nThe project is being developed with the goal of making advanced creative technology accessible to people around the world.",
                        color = DIM,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                    Text(text = "Founder: Malik Huzaifa", color = TXT)
                    Text(text = "Country: Pakistan", color = TXT)
                    Text(text = "“Imagine it. Describe it. Let AI turn it into a movie.”", color = BLUE, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }
}

fun createJob(baseUrl: String, script: String, duration: String): String {
    val connection = URL(baseUrl.trimEnd('/') + "/generate").openConnection() as HttpURLConnection
    connection.requestMethod = "POST"
    connection.connectTimeout = 20000
    connection.readTimeout = 30000
    connection.doOutput = true
    connection.setRequestProperty("Content-Type", "application/json")
    val body = JSONObject().apply {
        put("script", script)
        put("duration", duration)
    }.toString()
    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    val response = connection.inputStream.bufferedReader().use { it.readText() }
    connection.disconnect()
    return JSONObject(response).getString("job_id")
}

fun getJob(baseUrl: String, jobId: String): JobResult {
    val connection = URL(baseUrl.trimEnd('/') + "/status/" + Uri.encode(jobId)).openConnection() as HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 20000
    connection.readTimeout = 30000
    val response = connection.inputStream.bufferedReader().use { it.readText() }
    connection.disconnect()
    val json = JSONObject(response)
    return JobResult(
        id = jobId,
        status = json.optString("status", "queued"),
        progress = json.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f),
        videoUrl = json.optString("video_url", "").ifBlank { null }
    )
}

class VideoViewRef {
    var view: VideoView? = null
}

fun downloadVideo(baseUrl: String, videoUrl: String) {
    val context = AppContextHolder.context ?: return
    val finalUrl = if (videoUrl.startsWith("http")) videoUrl else baseUrl.trimEnd('/') + videoUrl
    val request = DownloadManager.Request(Uri.parse(finalUrl))
        .setTitle("CineForge AI Movie")
        .setDescription("Downloading generated movie")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "CineForgeAI_Movie.mp4")
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    manager.enqueue(request)
}

object AppContextHolder {
    var context: Context? = null
}

package com.cineforge.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG=Color(0xFF080A16); private val CARD=Color(0xFF12162A); private val TXT=Color(0xFFF5F7FF); private val DIM=Color(0xFFA8AEC5); private val BLUE=Color(0xFF55A7FF)

class MainActivity: ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{CineForgeApp()}}
}

@Composable fun CineForgeApp(){
 var s by remember{mutableStateOf("home")}
 MaterialTheme(colorScheme=darkColorScheme(background=BG,surface=CARD,primary=BLUE)){
  Surface(Modifier.fillMaxSize(),color=BG){
   when(s){
    "create"->Create({s="home"},{s="generating"})
    "generating"->Generating({s="home"},{s="movie"})
    "movie"->Movie({s="home"})
    "library"->Library({s="home"})
    "about"->About({s="home"})
    else->Home({s="create"},{s="library"},{s="about"})
   }
  }
 }
}

@Composable fun Header(t:String,sub:String?=null,back:(()->Unit)?=null){
 Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){
  if(back!=null)Text("‹",color=TXT,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(end=12.dp))
  Column{Text(t,color=TXT,fontSize=25.sp,fontWeight=FontWeight.Bold);sub?.let{Text(it,color=DIM,fontSize=13.sp)}}
 }
}
@Composable fun BoxCard(c:@Composable ColumnScope.()->Unit){
 Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(CARD,Color(0xFF171B35))),RoundedCornerShape(20.dp)).padding(18.dp),content=c)
}
@Composable fun ButtonX(t:String,click:()->Unit){Button(click,Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text(t,fontWeight=FontWeight.Bold)}}

@Composable fun Home(create:()->Unit,lib:()->Unit,about:()->Unit){
 Column(Modifier.fillMaxSize()){
  Header("CineForge AI","Your Idea. Your Story. Your Movie.")
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item{BoxCard{Text("AI Movie Maker",color=TXT,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Paste a complete screenplay and target duration. CineForge is designed to handle scenes, voices, lip-sync, sound and video.",color=DIM,modifier=Modifier.padding(vertical=8.dp));ButtonX("＋ Create New Movie",create)}}
   item{Tile("🎬","My Movies","View projects",lib)}
   item{Tile("✦","Free Mode","Open/free backends where available",{})}
   item{Tile("ⓘ","About CineForge AI","Founder and project information",about)}
  }
  Bottom(lib,about)
 }
}
@Composable fun Tile(i:String,t:String,d:String,click:()->Unit){BoxCard{Row(Modifier.fillMaxWidth().clickable{click()},verticalAlignment=Alignment.CenterVertically){Text(i,fontSize=27.sp);Spacer(Modifier.width(15.dp));Column(Modifier.weight(1f)){Text(t,color=TXT,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(d,color=DIM,fontSize=13.sp)};Text("›",color=DIM,fontSize=27.sp)}}}
@Composable fun Bottom(lib:()->Unit,profile:()->Unit){Row(Modifier.fillMaxWidth().background(Color(0xFF0C0F20)).padding(10.dp),horizontalArrangement=Arrangement.SpaceEvenly){Text("⌂ Home",color=TXT,Modifier.padding(10.dp));Text("▣ Library",color=DIM,Modifier.clickable{lib()}.padding(10.dp));Text("● Profile",color=DIM,Modifier.clickable{profile()}.padding(10.dp))}}

@Composable fun Create(back:()->Unit,generate:()->Unit){
 var script by remember{mutableStateOf("")};var dur by remember{mutableStateOf("10 minutes")}
 Column(Modifier.fillMaxSize()){Header("Create New Movie","Complete screenplay + duration",back)
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item{BoxCard{Text("FULL SCREENPLAY",color=BLUE,fontSize=12.sp,fontWeight=FontWeight.Bold);OutlinedTextField(script,{script=it},Modifier.fillMaxWidth().height(280.dp),placeholder={Text("Paste your complete movie screenplay here…")})}}
   item{BoxCard{Text("MOVIE DURATION",color=TXT,fontWeight=FontWeight.Bold);OutlinedTextField(dur,{dur=it},Modifier.fillMaxWidth(),placeholder={Text("e.g. 3 hours")})}}
   item{BoxCard{Text("PIPELINE",color=TXT,fontWeight=FontWeight.Bold);Text("Script → scenes → characters → voices → lip-sync → music/SFX → video → final movie",color=DIM,modifier=Modifier.padding(top=8.dp))}}
  }
  Box(Modifier.padding(20.dp)){ButtonX("Generate Movie",generate)}
 }
}
@Composable fun Generating(back:()->Unit,done:()->Unit){
 var p by remember{mutableStateOf(0f)};var status by remember{mutableStateOf("Analyzing screenplay…")}
 LaunchedEffect(Unit){val a=listOf("Analyzing screenplay…","Building characters…","Breaking into scenes…","Preparing voices…","Generating video scenes…","Applying lip-sync…","Adding music & SFX…","Compiling final movie…");a.forEachIndexed{i,x->kotlinx.coroutines.delay(550);status=x;p=(i+1)/a.size.toFloat()}}
 Column(Modifier.fillMaxSize()){Header("Generating Your Movie","Long jobs can run on the backend",back);Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){BoxCard{Text("CineForge AI",color=TXT,fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));LinearProgressIndicator({p},Modifier.fillMaxWidth());Text("${(p*100).toInt()}% • $status",color=DIM,modifier=Modifier.padding(top=10.dp))};BoxCard{Text("Pipeline",color=TXT,fontWeight=FontWeight.Bold);listOf("Story & scenes","Characters","Voices","Lip-sync","Music/SFX","Final assembly").forEach{Text("✓  $it",color=DIM,modifier=Modifier.padding(vertical=5.dp))}};if(p>=.99f)ButtonX("Preview Final Movie",done)}}}
@Composable fun Movie(back:()->Unit){Column(Modifier.fillMaxSize()){Header("Final Movie","Preview and edit",back);Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Box(Modifier.fillMaxWidth().height(210.dp).background(Color.Black,RoundedCornerShape(20.dp)),contentAlignment=Alignment.Center){Text("▶",color=TXT,fontSize=55.sp)};BoxCard{Text("Generated Movie",color=TXT,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Backend-rendered movie will appear here.",color=DIM)};ButtonX("Edit / Regenerate Scene",{});OutlinedButton({},Modifier.fillMaxWidth().height(52.dp)){Text("Download Movie")}}}}
@Composable fun Library(home:()->Unit){Column(Modifier.fillMaxSize()){Header("My Movies","Your projects");LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){items(listOf("Untitled Movie","My First Story","CineForge Test")){Tile("🎞",it,"Movie project",{})}};Bottom({},home)}}
@Composable fun About(back:()->Unit){Column(Modifier.fillMaxSize()){Header("About CineForge AI","The idea behind the app",back);LazyColumn(contentPadding=PaddingValues(20.dp)){item{BoxCard{Text("Meet the Founder",color=TXT,fontSize=23.sp,fontWeight=FontWeight.Bold);Text("This application was born from an idea to make AI-powered filmmaking simple and accessible to everyone.\n\nMalik Huzaifa is the founder and the person behind the concept of this application. The vision is to create a powerful AI movie-making experience where anyone can turn a simple text or voice idea into a complete cinematic story — including characters, dialogue, voices, scenes, music, sound effects, animation, and video.\n\nThe application is being developed with the goal of making advanced creative technology accessible to people around the world, while proudly carrying an idea from Pakistan to a global audience.",color=DIM,modifier=Modifier.padding(vertical=12.dp));Text("Founder: Malik Huzaifa",color=TXT);Text("Country: Pakistan",color=TXT);Text("Contact: 03454112418",color=TXT);Text("“Imagine it. Describe it. Let AI turn it into a movie.”",color=BLUE,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))}}}}}

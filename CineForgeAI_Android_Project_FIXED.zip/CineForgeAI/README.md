# CineForge AI
Free-first Android client prototype for the planned AI movie maker.

Workflow:
Full screenplay + duration → scenes → characters → voices → lip-sync → video → music/SFX → FFmpeg assembly.

The heavy AI generation is deliberately separated from the Android client. This keeps a low-end phone lightweight.

No paid API is hard-coded. Production still needs free/open-source backend adapters and multiple provider fallbacks. Free compute services can impose quotas/queues, so unlimited free rendering cannot honestly be guaranteed.

Build with Android Studio and Android SDK 35. The APK is not claimed to be compiled in this environment because a complete Android SDK/Gradle build toolchain is unavailable here.

package com.cineforge.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val BG = Color(0xFF080A16)
private val CARD = Color(0xFF12162A)
private val TXT = Color(0xFFF5F7FF)
private val DIM = Color(0xFFA8AEC5)
private val BLUE = Color(0xFF55A7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CineForgeApp() }
    }
}

@Composable
fun CineForgeApp() {
    var screen by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = CARD, primary = BLUE)) {
        Surface(modifier = Modifier.fillMaxSize(), color = BG) {
            when (screen) {
                "create" -> Create(back = { screen = "home" }, generate = { screen = "generating" })
                "generating" -> Generating(back = { screen = "home" }, done = { screen = "movie" })
                "movie" -> Movie(back = { screen = "home" })
                "library" -> Library(home = { screen = "home" })
                "about" -> About(back = { screen = "home" })
                else -> Home(create = { screen = "create" }, lib = { screen = "library" }, about = { screen = "about" })
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null, back: (() -> Unit)? = null) {
    Row(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) {
            Text(text = "‹", color = TXT, fontSize = 34.sp, modifier = Modifier.clickable { back() }.padding(end = 12.dp))
        }
        Column {
            Text(text = title, color = TXT, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(text = subtitle, color = DIM, fontSize = 13.sp)
        }
    }
}

@Composable
fun BoxCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().background(
            brush = Brush.linearGradient(colors = listOf(CARD, Color(0xFF171B35))),
            shape = RoundedCornerShape(20.dp)
        ).padding(18.dp),
        content = content
    )
}

@Composable
fun ButtonX(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
        Text(text = text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Home(create: () -> Unit, lib: () -> Unit, about: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "CineForge AI", subtitle = "Your Idea. Your Story. Your Movie.")
        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                BoxCard {
                    Text(text = "AI Movie Maker", color = TXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Paste a complete screenplay and target duration. CineForge is designed to handle scenes, voices, lip-sync, sound and video.", color = DIM, modifier = Modifier.padding(vertical = 8.dp))
                    ButtonX(text = "＋ Create New Movie", onClick = create)
                }
            }
            item { Tile(icon = "🎬", title = "My Movies", description = "View projects", onClick = lib) }
            item { Tile(icon = "✦", title = "Free Mode", description = "Open/free backends where available", onClick = {}) }
            item { Tile(icon = "ⓘ", title = "About CineForge AI", description = "Founder and project information", onClick = about) }
        }
        Bottom(lib = lib, profile = about)
    }
}

@Composable
fun Tile(icon: String, title: String, description: String, onClick: () -> Unit) {
    BoxCard {
        Row(modifier = Modifier.fillMaxWidth().clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
            Text(text = icon, fontSize = 27.sp)
            Spacer(modifier = Modifier.width(15.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TXT, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(text = description, color = DIM, fontSize = 13.sp)
            }
            Text(text = "›", color = DIM, fontSize = 27.sp)
        }
    }
}

@Composable
fun Bottom(lib: () -> Unit, profile: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF0C0F20)).padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        Text(text = "⌂ Home", color = TXT, modifier = Modifier.padding(10.dp))
        Text(text = "▣ Library", color = DIM, modifier = Modifier.clickable { lib() }.padding(10.dp))
        Text(text = "● Profile", color = DIM, modifier = Modifier.clickable { profile() }.padding(10.dp))
    }
}

@Composable
fun Create(back: () -> Unit, generate: () -> Unit) {
    var script by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("10 minutes") }
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Create New Movie", subtitle = "Complete screenplay + duration", back = back)
        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                BoxCard {
                    Text(text = "FULL SCREENPLAY", color = BLUE, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = script, onValueChange = { script = it }, modifier = Modifier.fillMaxWidth().height(280.dp), placeholder = { Text(text = "Paste your complete movie screenplay here…") })
                }
            }
            item {
                BoxCard {
                    Text(text = "MOVIE DURATION", color = TXT, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = duration, onValueChange = { duration = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(text = "e.g. 3 hours") })
                }
            }
            item {
                BoxCard {
                    Text(text = "PIPELINE", color = TXT, fontWeight = FontWeight.Bold)
                    Text(text = "Script → scenes → characters → voices → lip-sync → music/SFX → video → final movie", color = DIM, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        Box(modifier = Modifier.padding(20.dp)) { ButtonX(text = "Generate Movie", onClick = generate) }
    }
}

@Composable
fun Generating(back: () -> Unit, done: () -> Unit) {
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("Analyzing screenplay…") }
    LaunchedEffect(Unit) {
        val stages = listOf("Analyzing screenplay…", "Building characters…", "Breaking into scenes…", "Preparing voices…", "Generating video scenes…", "Applying lip-sync…", "Adding music & SFX…", "Compiling final movie…")
        stages.forEachIndexed { index, stage ->
            delay(550)
            status = stage
            progress = (index + 1) / stages.size.toFloat()
        }
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Generating Your Movie", subtitle = "Long jobs can run on the backend", back = back)
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            BoxCard {
                Text(text = "CineForge AI", color = TXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
                Text(text = "${(progress * 100).toInt()}% • $status", color = DIM, modifier = Modifier.padding(top = 10.dp))
            }
            BoxCard {
                Text(text = "Pipeline", color = TXT, fontWeight = FontWeight.Bold)
                listOf("Story & scenes", "Characters", "Voices", "Lip-sync", "Music/SFX", "Final assembly").forEach { step ->
                    Text(text = "✓  $step", color = DIM, modifier = Modifier.padding(vertical = 5.dp))
                }
            }
            if (progress >= 0.99f) ButtonX(text = "Preview Final Movie", onClick = done)
        }
    }
}

@Composable
fun Movie(back: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "Final Movie", subtitle = "Preview and edit", back = back)
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(modifier = Modifier.fillMaxWidth().height(210.dp).background(Color.Black, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                Text(text = "▶", color = TXT, fontSize = 55.sp)
            }
            BoxCard {
                Text(text = "Generated Movie", color = TXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(text = "Backend-rendered movie will appear here.", color = DIM)
            }
            ButtonX(text = "Edit / Regenerate Scene", onClick = {})
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(text = "Download Movie") }
        }
    }
}

@Composable
fun Library(home: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "My Movies", subtitle = "Your projects")
        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(listOf("Untitled Movie", "My First Story", "CineForge Test")) { movie ->
                Tile(icon = "🎞", title = movie, description = "Movie project", onClick = {})
            }
        }
        Bottom(lib = {}, profile = home)
    }
}

@Composable
fun About(back: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(title = "About CineForge AI", subtitle = "The idea behind the app", back = back)
        LazyColumn(contentPadding = PaddingValues(20.dp)) {
            item {
                BoxCard {
                    Text(text = "Meet the Founder", color = TXT, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(text = "This application was born from an idea to make AI-powered filmmaking simple and accessible to everyone.

Malik Huzaifa is the founder and the person behind the concept of this application. The vision is to create a powerful AI movie-making experience where anyone can turn a simple text or voice idea into a complete cinematic story — including characters, dialogue, voices, scenes, music, sound effects, animation, and video.

The application is being developed with the goal of making advanced creative technology accessible to people around the world, while proudly carrying an idea from Pakistan to a global audience.", color = DIM, modifier = Modifier.padding(vertical = 12.dp))
                    Text(text = "Founder: Malik Huzaifa", color = TXT)
                    Text(text = "Country: Pakistan", color = TXT)
                    Text(text = "Contact: 03454112418", color = TXT)
                    Text(text = "“Imagine it. Describe it. Let AI turn it into a movie.”", color = BLUE, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }
}
